import { getAuth, signInWithCustomToken, signOut} from "firebase/firebase-auth.js";

var admin = require("firebase-admin");
var serviceAccount = require("oscario-1782a-firebase-adminsdk-7tskw-d38303cc9d.json");
