/*
Vars
const audC = document.getElementById('audcontrols')
const aud = document.getElementById('aud')

scripting
*/
